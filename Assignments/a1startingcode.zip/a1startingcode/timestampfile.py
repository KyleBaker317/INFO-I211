#!/usr/bin/python


# this does *not* work for cron-launched scripts:
#   /usr/bin/env python
# since the standard UNIX login shell "environment" is not present.

import datetime
import time
import os
import sys

SNAPSHOTFILENAME = "snapshot.jpg"
LOCALPATH = "/u/username/tmp"
CGIDATAPATH = "/u/username/cgi-pub/i211/a1/data"

gFilePath = ""
gFileMTime = -1

def printPythonVersion():
    print "--------------------------------------------------"
    print "this is Python version:"
    print sys.version
    print "--------------------------------------------------"


if __name__ == "__main__":

    printPythonVersion()

    gFilePath = os.path.join(LOCALPATH, SNAPSHOTFILENAME)

    print LOCALPATH
    print SNAPSHOTFILENAME
    print gFilePath
    
    # test that the file exists and that it can be read:
    if os.access(gFilePath, os.R_OK):
        gFileMTime = os.path.getmtime(gFilePath)
        print gFileMTime
        gFromTimeStamp = datetime.datetime.fromtimestamp(gFileMTime)
        print gFromTimeStamp
        gTimeTuple = datetime.datetime.timetuple(gFromTimeStamp)
        print gTimeTuple
        gStringTimeStamp = time.strftime("%Y%m%d%H%M%S",gTimeTuple)
        print gStringTimeStamp
        newname = str(gStringTimeStamp)+"_"+SNAPSHOTFILENAME
        newfilepath = os.path.join(CGIDATAPATH, newname)
        # print "newname = ", newname
        # print "newfilepath = ", newfilepath
        os.rename(gFilePath, newfilepath)
    else:
        print "bad gFilePath = ", gFilePath


