#!/bin/bash

# this bash-shell script is used to
#   save one still image captured from a camera to a local file

# the "imagesnap" command-line executable
#   captures one still image from the default camera on Mac OS X
#   the "-w 1.00" option is used for a "warm-up" time of 1 second,
#   required by some built-in cameras:

./imagesnap -w 1.00 

# done! by default the image is saved into a file "snapshot.jpg"

chmod ugo+r snapshot.jpg



# more information about command line options, as well as
# the source code for the  imagesnap program is available at:
#  http://iharder.net/imagesnap
