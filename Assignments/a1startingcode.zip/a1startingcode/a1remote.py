#!/usr/bin/python

import sys  # for sys.version

import os   # for os.environ(), etc.

import subprocess   # for call()


SNAPSHOTFILENAME = "snapshot.jpg" # snapshot.bmp for Windows
USERNAME = "username"
HOSTNAME = "silo.soic.indiana.edu"
REMOTEPATH = "/u/username/tmp"

gPlatform = " "
gScpExecutable = " "
gScpCommand = " "


def printPythonVersion():
    print "--------------------------------------------------"
    print "this is Python version:"
    print sys.version
    print "--------------------------------------------------"


def searchPath(executable):
    '''Find scp on the PATH
    '''
    for i in os.environ.get('PATH',os.defpath).split(os.pathsep): 
        print "i = ", i
        t = os.path.join(i, executable)
        print "t = ", t
        if os.access(t,os.X_OK): 
            print "t = ", t, "works!"
            return t
    # Else:
    return None


def testPlatform():
    if sys.platform.startswith('win'):
        print "Windows"
        return ("w")
    elif sys.platform=='darwin':
        print "Mac OS X"
        return ("m")
    else:
        print "Linux or...?"
        return ("l")


if __name__ == "__main__":

    printPythonVersion()

    gPlatform = testPlatform()
    if (gPlatform == "w") :
        subprocess.call("./windowssnapshot.bat")
        gScpExecutable = " "
    elif (gPlatform == "m") :
        subprocess.call("./macosxsnapshot.sh")
        gScpExecutable = "scp"
    else:
        print "operating system not yet supported"
        # terminate program execution and return error code:
        sys.exit(1)
    
    gScpCommand = searchPath(gScpExecutable)
    print  "gScpCommand = ", gScpCommand 

    # copy to server using ssh:
    if (gPlatform == "w") :
        subprocess.call("./windowspscpfile.bat")
    elif (gPlatform == "m") :
        subprocess.call(gScpCommand+" -p "+SNAPSHOTFILENAME+" "+USERNAME+"@"+HOSTNAME+":"+REMOTEPATH, shell=True)

    print "copy done!"

