# Property Critter
# Demonstrates get and set methods and properties
# using semi-private attributes

class Critter(object):
    """A virtual pet"""
    def __init__(self, name):
        print "A new critter has been born!"
        self._name = name

    def get_name(self):
        return self._name

    def set_name(self, new_name):
        if new_name == "":
            print "A critter's name can't be the empty string."
        else:
            self._name = new_name
            print "Name change successful."

    name = property(get_name, set_name)

    def talk(self):
        print "\nHi, I'm", self.name

# main
crit = Critter("Poochie")
crit.talk()

print "\nMy critter's name is:",
print crit.name
print "\nAttempting to change my critter's name."
crit.name = ""
print "\nAttempting to change my critter's name again."
crit.name = "Randolph"

crit.talk()

print "\nOverriding the semi-privacy to set crit._name directly."
crit._name = "Poochie"

crit.talk()

raw_input("\n\nPress the enter key to exit.")
