# Semi-Private Critter
# Demonstrates semi-private variables and methods

class Critter(object):
    """A virtual pet"""
    def __init__(self, name, mood):
        print "A new critter has been born!"
        self.name = name            # public attribute
        self._mood = mood           # semi-private attribute

    def talk(self):
        print "\nI'm", self.name
        print "Right now I feel", self._mood, "\n"

    def _private_method(self):
        print "This is a semi-private method."

    def public_method(self):
        print "This is a public method."
        self._private_method()

# main
crit = Critter(name = "Poochie", mood = "happy")
crit.talk()
crit.public_method()

raw_input("\n\nPress the enter key to exit.")
